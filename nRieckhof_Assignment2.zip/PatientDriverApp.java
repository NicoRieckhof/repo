/*
  Class: CMSC203 CRN23011
  Program: Assignment 2
  Instructor: Prof. Huseyin Aygun
  Description: This program creates a profile for a patient and their medical records.
  Due: 09/28/2026
  Platform/Compiler: Eclipse
  Integrity Pledge: I pledge that I have completed the programming assignment independently.
  I have not copied the code from a student or any source.
  Student Name: Nicolas Rieckhof
*/

import java.util.Scanner;

/**
 * This class handles most of the input and output for the assignment.
 * The class creates the Patient object and the Procedure objects.
 */
public class PatientDriverApp {

	/**
     * Stores all patient details and returns a new Patient object.
     * @param input the Scanner for reading input
     * @return the detailed Patient object
     */
	public static Patient inputPatient(Scanner input) {
		System.out.print("Enter first name: ");
		String first = input.nextLine();
		System.out.print("Enter middle name: ");
		String middle = input.nextLine();
		System.out.print("Enter last name: ");
		String last = input.nextLine();
		System.out.print("Enter street address: ");
		String address = input.nextLine();
		System.out.print("Enter city: ");
		String city = input.nextLine();
		System.out.print("Enter state: ");
		String state = input.nextLine();
		System.out.print("Enter zip: ");
		String zip = input.nextLine();
		System.out.print("Enter phone number (###-###-####): ");
		String phone = input.nextLine();
		System.out.print("Enter emergency contact name: ");
		String emName = input.nextLine();
		System.out.print("Enter emergency contact phone (###-###-####): ");
		String emPhone = input.nextLine();
		System.out.println('\n');
		
		return new Patient(first, middle, last, address, city, 
						   state, zip, phone, emName, emPhone);
	}
	
	/**
     * Creates the first procedure.
     * @return the first Procedure object
     */
	public static Procedure createProcedure1() {
		Procedure p1 = new Procedure();
		
		p1.setProcedureName("Physical Exam");
		p1.setDate("07/20/2026");
		p1.setPractitionerName("Dr. Irvine");
		p1.setCharges(250);
		
		return p1;
	}
	/**
     * Creates the second procedure.
     * @return the second Procedure object
     */
	public static Procedure createProcedure2() {
		Procedure p2 = new Procedure("X-ray", "07/20/2026");
		
		p2.setPractitionerName("Dr. Jamison");
		p2.setCharges(550.43);
		
		return p2;
	}
	/**
     * Creates the third procedure.
     * @return the third Procedure object
     */
	public static Procedure createProcedure3() {
		Procedure p3 = new Procedure("Blood Test", "07/20/2026", "Dr. Smith", 1400.75);
		
		return p3;
	}
	/**
     * Displays formatted patient info.
     * @param patient the Patient to display
     */
	public static void displayPatient(Patient patient)
		{ System.out.println(patient.getContactSummary()); }
	/**
     * Displays a procedure's details.
     * @param procedure the Procedure to display
     */
	public static void displayProcedure(Procedure procedure)
		{ System.out.println(procedure.toString()); }
	/**
     * Displays three procedures in a format.
     * @param p1 the first procedure
     * @param p2 the second procedure
     * @param p3 the third procedure
     */
	public static void displayProcedureTable(Procedure p1, Procedure p2, Procedure p3) {
		System.out.println("Procedure            Date        Practitioner    Charge      Category");
		System.out.println("______________________________________________________________________");
		System.out.println(p1.getProcedureName() + "     " + p1.getDate() + "     " + p1.getPractitionerName() + "     " + p1.getFormattedCharge() + "        " + p1.getChargeCategory());
		System.out.println(p2.getProcedureName() + "             " + p2.getDate() + "     " + p2.getPractitionerName() + "    " + p2.getFormattedCharge() + "       " + p2.getChargeCategory());
		System.out.println(p3.getProcedureName() + "        " + p3.getDate() + "     " + p3.getPractitionerName() + "      " + p3.getFormattedCharge() + "      " + p3.getChargeCategory());
	}
	/**
     * Calculates the total cost of the three procedures.
     * @param p1 the first procedure
     * @param p2 the second procedure
     * @param p3 the third procedure
     * @return cost of all three procedure charges
     */
	public static double calculateTotalCharges(Procedure p1, Procedure p2, Procedure p3)
		{ return p1.getCharges() + p2.getCharges() + p3.getCharges(); }
	/**
     * Calculates the average charge of the three procedures.
     * @param p1 the first procedure
     * @param p2 the second procedure
     * @param p3 the third procedure
     * @return average cost
     */
	public static double calculateAverageCharge(Procedure p1, Procedure p2, Procedure p3)
		{ return calculateTotalCharges(p1, p2, p3) / 3.0; }
	/**
     * Finds the procedure with the highest charge.
     * @param p1 the first procedure
     * @param p2 the second procedure
     * @param p3 the third procedure
     * @return procedure object having the maximum charge
     */
	public static Procedure findHighestChargeProcedure(Procedure p1, Procedure p2, Procedure p3) {
		Procedure highestP = p1;
		if (p2.getCharges() > highestP.getCharges()) {
			highestP = p2;
		}
		if (p3.getCharges() > highestP.getCharges()) {
			highestP = p3;
		}
		return highestP;
	}
	/**
     * Counts how many procedures charge $1000 or more.
     * @param p1 the first procedure
     * @param p2 the second procedure
     * @param p3 the third procedure
     * @return number of expensive procedures
     */
	public static int countExpensiveProcedures(Procedure p1, Procedure p2, Procedure p3) {
		int c = 0;
		if (p1.isExpensiveProcedure())
			c++;
		if (p2.isExpensiveProcedure())
			c++;
		if (p3.isExpensiveProcedure())
			c++;
		return c;
	}
	/**
     * Displays summary of cost details
     * @param p1 the first procedure
     * @param p2 the second procedure
     * @param p3 the third procedure
     */
	public static void displaySummary(Procedure p1, Procedure p2, Procedure p3) {
		double totalCharges = calculateTotalCharges(p1, p2, p3);
		double averageCharge = calculateAverageCharge(p1, p2, p3);
		Procedure highestP = findHighestChargeProcedure(p1, p2, p3);
		int numOfExpensiveProcedures = countExpensiveProcedures(p1, p2, p3);
		
		System.out.printf("Total Charges: $%,.2f\n", totalCharges);
        System.out.printf("Average Charge: $%,.2f\n", averageCharge);
        System.out.println("Highest Charge Procedure: " + highestP.getProcedureName());
        System.out.println("Number of Expensive Procedures: " + numOfExpensiveProcedures);
        System.out.println();
	}
	
	public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        // Store and display patient info
        Patient patient = inputPatient(input);
        displayPatient(patient);

        // Create the three procedures
        Procedure p1 = createProcedure1();
        Procedure p2 = createProcedure2();
        Procedure p3 = createProcedure3();
        
        // Display the three procedures on a formatted table
        displayProcedureTable(p1, p2, p3);

        // Display summary of the procedures
        displaySummary(p1, p2, p3);

        System.out.println("The program was developed by a Student: Nicolas Rieckhof 09/28/26");
    }

}
