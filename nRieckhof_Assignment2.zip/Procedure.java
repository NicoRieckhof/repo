/*
  Class: CMSC203 CRN23011
  Program: Assignment 2
  Instructor: Prof. Huseyin Aygun
  Description: This program creates a profile for a patient and their medical records.
  Due: 09/28/2026
  Platform/Compiler: Eclipse
  Integrity Pledge: I pledge that I have completed the programming assignment independently.
  I have not copied the code from a student or any source.
  Student Name: Nicolas Rieckhof
*/

/**
 * This class stores the details of a medical procedure such as the name, date, practitioner, and cost.
 */
public class Procedure {

	private String procedureName;
	private String date;
	private String practitionerName;
	private double charges;
	
	// Constructors
	
	/**
	 * No-arg constructor that assigns everything to default values.
	 */
	public Procedure() {
		procedureName = "";
		date = "";
		practitionerName = "";
		charges = 0;
	}
	/**
	 * Constructor that initializes just the procedure name and date.
	 * @param n the procedure name
	 * @param d the procedure date
	 */
	public Procedure(String n, String d) {
		procedureName = n;
		date = d;
		practitionerName = "";
		charges = 0;
	}
	/**
	 * Constructor that initializes all attributes of the procedure.
	 * @param procedureN the procedure name
	 * @param d the procedure date
	 * @param practitionerN the practitioner name
	 * @param c the procedure charges
	 */
	public Procedure(String procedureN, String d, String practitionerN, double c) {
		procedureName = procedureN;
		date = d;
		practitionerName = practitionerN;
		charges = c;
	}
	
	// Required Methods
	
	/**
	 * Gets the procedure name.
	 * @return the procedure name
	 */
	public String getProcedureName()
		{ return procedureName; }
	/**
	 * Gets the procedure date.
	 * @return the procedure date
	 */
	public String getDate()
		{ return date; }
	/**
	 * Gets the practitioner's name.
	 * @return the practitioner's name
	 */
	public String getPractitionerName()
		{ return practitionerName; }
	/**
	 * Gets the charges for the procedure.
	 * @return the charges
	 */
	public double getCharges()
		{ return charges; }
	/**
	 * Sets the procedure name.
	 * @param n the procedure name to set
	 */
	public void setProcedureName(String n)
		{ procedureName = n; }
	/**
	 * Sets the procedure date.
	 * @param d the procedure date to set
	 */
	public void setDate(String d)
		{ date = d; }
	/**
	 * Sets the practitioner's name.
	 * @param n the practitioner's name to set
	 */
	public void setPractitionerName(String n)
		{ practitionerName = n; }
	/**
	 * Sets the charges for the procedure.
	 * @param c the charges to set
	 */
	public void setCharges(double c)
		{ charges = c; }
	/**
	 * Returns the procedure information.
	 * @return formatted string of procedure details
	 */
	public String toString() {
		return getProcedureName() + '\n' +
			   getDate() + '\n' + 
			   getPractitionerName() + '\n' +
			   getFormattedCharge();
	}
	
	// Additional Methods
	
	/**
	 * Checks whether the procedure is expensive.
	 * @return true if charges is 1000 or more and false if not
	 */
	public boolean isExpensiveProcedure()
		{ return charges >= 1000; }
	/**
	 * Applies a percentage discount to the charges it's a valid percentage.
	 * @param percent the discount percentage
	 */
	public void applyDiscount(double percent) {
		if (percent >= 0 && percent <= 100) {
			charges -= charges * (percent / 100.0);
		}
	}
	/**
	 * Determines the charge category.
	 * @return the charge category
	 */
	public String getChargeCategory() {
		if (charges >= 1000) {
			return "High";
		}
		else if (charges >= 500) {
			return "Medium";
		}
		else {
			return "Low";
		}
	}
	/**
	 * Checks if the procedure was performed the practitioner.
	 * @param name the name of the practitioner to compare
	 * @return true if the practitioner matches and false if not
	 */
	public boolean isPerformedBy(String name)
		{ return practitionerName.equalsIgnoreCase(name); }
	/**
	 * Formats the procedure charge.
	 * @return the formatted charge string
	 */
	public String getFormattedCharge()
		{ return String.format("$%,.2f", charges); }
}
