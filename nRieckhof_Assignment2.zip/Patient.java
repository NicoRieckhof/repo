/*
  Class: CMSC203 CRN23011
  Program: Assignment 2
  Instructor: Prof. Huseyin Aygun
  Description: This program creates a profile for a patient and their medical records.
  Due: 09/28/2026
  Platform/Compiler: Eclipse
  Integrity Pledge: I pledge that I have completed the programming assignment independently.
  I have not copied the code from a student or any source.
  Student Name: Nicolas Rieckhof
*/

/**
 * The Patient class stores a patient's details such as their name, address, and phone numbers.
 */
public class Patient {
	
	private String firstName;
	private String middleName;
	private String lastName;
	private String streetAddress;
	private String city;
	private String state;
	private String zipCode;
	private String phoneNumber;
	private String emergencyContactName;
	private String emergencyContactPhoneNumber;
	
	// Constructors
	
	/**
     * No-arg constructor that initializes everything to empty strings.
     */
	public Patient() {
		firstName = "";
		middleName = "";
		lastName = "";
		streetAddress = "";
		city = "";
		state = "";
		zipCode = "";
		phoneNumber = "";
		emergencyContactName = "";
		emergencyContactPhoneNumber = "";
	}
	/**
     * Constructor that initializes just the first, middle, and last names.
     * @param first  the patient's first name
     * @param middle the patient's middle name
     * @param last   the patient's last name
     */
	public Patient(String first, String middle, String last) {
		firstName = first;
		middleName = middle;
		lastName = last;
		streetAddress = "";
		city = "";
		state = "";
		zipCode = "";
		phoneNumber = "";
		emergencyContactName = "";
		emergencyContactPhoneNumber = "";
	}
	/**
     * Constructor that initializes everything.
     * @param first the first name
     * @param middle the middle name
     * @param last the last name
     * @param street the street address
     * @param c the city
     * @param s the state
     * @param z the ZIP code
     * @param p the phone number
     * @param eN the emergency contact name
     * @param ePN the emergency contact phone number
     */
	public Patient(String first, String middle, String last, 
				   String a, String c, String s, String z,
				   String p, String eN, String ePN) {
		firstName = first;
		middleName = middle;
		lastName = last;
		streetAddress = a;
		city = c;
		state = s;
		zipCode = z;
		phoneNumber = p;
		emergencyContactName = eN;
		emergencyContactPhoneNumber = ePN;
	}
	
	// Setters & Getters
	
	/**
	 * Sets the patient's first name.
	 * @param first the first name to set
	 */
	public void setFirstName(String first)
		{ firstName = first; }
	/**
	 * Sets the patient's middle name.
	 * @param middle the middle name to set
	 */
	public void setMiddleName(String middle)
		{ middleName = middle; }
	/**
	 * Sets the patient's last name.
	 * @param last the last name to set
	 */
	public void setLastName(String last)
		{ lastName = last; }
	/**
	 * Sets the patient's street address.
	 * @param a the street address to set
	 */
	public void setStreetAddress(String a)
		{ streetAddress = a; }
	/**
	 * Sets the patient's city.
	 * @param c the city to set
	 */
	public void setCity(String c)
		{ city = c; }
	/**
	 * Sets the patient's state.
	 * @param s the state to set
	 */
	public void setState(String s)
		{ state = s; }
	/**
	 * Sets the patient's ZIP code.
	 * @param z the ZIP code to set
	 */
	public void setZipCode(String z)
		{ zipCode = z; }
	/**
	 * Sets the patient's phone number.
	 * @param p the phone number to set
	 */
	public void setPhoneNumber(String p)
		{ phoneNumber = p; }
	/**
	 * Sets the emergency contact's name.
	 * @param eName the emergency contact name to set
	 */
	public void setEmergencyContactName(String eName)
		{ emergencyContactName = eName; }
	/**
	 * Sets the emergency contact's phone number.
	 * @param ePN the emergency contact phone number to set
	 */
	public void setEmergencyContactPhoneNumber(String ePN)
		{ emergencyContactPhoneNumber = ePN; }
	/**
	 * Gets the patient's first name.
	 * @return the first name
	 */
	public String getFirstName()
		{ return firstName; }
	/**
	 * Gets the patient's middle name.
	 * @return the middle name
	 */
	public String getMiddleName()
		{ return middleName; }
	/**
	 * Gets the patient's last name.
	 * @return the last name
	 */
	public String getLastName()
		{ return lastName; }
	/**
	 * Gets the patient's street address.
	 * @return the street address
	 */
	public String getStreetAddress()
		{ return streetAddress; }
	/**
	 * Gets the patient's city.
	 * @return the city
	 */
	public String getCity()
		{ return city; }
	/**
	 * Gets the patient's state.
	 * @return the state
	 */
	public String getState()
		{ return state; }
	/**
	 * Gets the patient's ZIP code.
	 * @return the ZIP code
	 */
	public String getZipCode()
		{ return zipCode; }
	/**
	 * Gets the patient's phone number.
	 * @return the phone number
	 */
	public String getPhoneNumber()
		{ return phoneNumber; }
	/**
	 * Gets the emergency contact's name.
	 * @return the emergency contact name
	 */
	public String getEmergencyContactName()
		{ return emergencyContactName; }
	/**
	 * Gets the emergency contact's phone number.
	 * @return the emergency contact phone number
	 */
	public String getEmergencyContactPhoneNumber()
		{ return emergencyContactPhoneNumber; }
	
	// Required Methods
	
	/**
	 * Returns the patient's full name.
	 * @return the combination of the first, middle, and last name
	 */
	public String buildFullName()
		{ return firstName + " " + middleName + " " + lastName; }
	/**
	 * Concatenates and returns the patient's address.
	 * @return the full address details
	 */
	public String buildAddress()
		{ return streetAddress + " " + city + " " + state + " " + zipCode; }
	/**
	 * Returns the emergency contact's name and phone number.
	 * @return the contact details together
	 */
	public String buildEmergencyContact()
		{ return emergencyContactName + " " + emergencyContactPhoneNumber; }
	/**
	 * Returns patient info
	 * @return string with the name, address, and emergency contact
	 */
	public String toString() {
		return buildFullName() + '\n' +
			   buildAddress() + '\n' +
			   buildEmergencyContact() + '\n';
	}
	
	// Additional Methods
	
	/**
	 * Checks if the patient's phone number is valid.
	 * @return true if valid, false if not
	 */
	public boolean isValidPhoneNumber() { 
		return phoneNumber != null && phoneNumber.length() == 12 && 
			   phoneNumber.charAt(3) == '-' && phoneNumber.charAt(7) == '-';
	}
	/**
	 * Check if the emergency contact phone number is valid.
	 * @return true if valid, false if not
	 */
	public boolean isValidEmergencyPhoneNumber() {
		return emergencyContactPhoneNumber != null && emergencyContactPhoneNumber.length() == 12 && 
			   emergencyContactPhoneNumber.charAt(3) == '-' && emergencyContactPhoneNumber.charAt(7) == '-';
	}
	/**
	 * Formats and returns the patient's name with the last name first.
	 * @return the full name in the format
	 */
	public String getLastFirstMiddle()
		{ return lastName + ", " + firstName + " " + middleName; }
	/**
	 * Determines whether the city and state match.
	 * @param c the city to compare
	 * @param s the state to compare
	 * @return true if both match, false if not
	 */
	public boolean hasSameCityState(String c, String s)
	    { return c.equalsIgnoreCase(city) && s.equalsIgnoreCase(state); }
	/**
	 * Updates the patient's address.
	 * @param street the updated street address
	 * @param c the updated city
	 * @param s the updated state
	 * @param z the updated ZIP code
	 */
	public void updateAddress(String street, String c, String s, String z) {
		streetAddress = street;
		city = c;
		state = s;
		zipCode = z;
	}
	/**
	 * Generates a full summary of the patient's info
	 * @return the patient's info as a format
	 */
	public String getContactSummary() {
		return "Patient Information\n" + 
			   "-------------------\n" +
				"Name: " + buildFullName() + '\n' +
				"Address: " + buildAddress() + '\n' +
				"Phone Number: " + phoneNumber + '\n' +
				"Emergency Contact: " + buildEmergencyContact() + '\n' +
				"Phone Valid: " + isValidPhoneNumber() + '\n' +
				"Emergency Phone Valid: " + isValidEmergencyPhoneNumber() + "\n\n";
	}
}
